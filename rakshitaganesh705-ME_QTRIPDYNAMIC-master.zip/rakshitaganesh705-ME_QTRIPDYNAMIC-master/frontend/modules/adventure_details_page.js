import config from "../conf/index.js";

//Implementation to extract adventure ID from query params
function getAdventureIdFromURL(search) {
  // TODO: MODULE_ADVENTURE_DETAILS
 
  // 1. Get the Adventure Id from the URL
  console.log(search);
  let params=new URLSearchParams(search);
  console.log(params.get('adventure'));
  return params.get('adventure');

  // Place holder for functionality to work in the Stubs
  return null;
}
//Implementation of fetch call with a paramterized input based on adventure ID
async function fetchAdventureDetails(adventureId) {

  console.log(adventureId);
  try{
    const data= await fetch(config.backendEndpoint+"/adventures/detail/?adventure="+adventureId);
    return await data.json();
  }
catch{
  return null;
}
  // TODO: MODULE_ADVENTURE_DETAILS
  // 1. Fetch the details of the adventure by making an API call


  // Place holder for functionality to work in the Stubs
  return null;
}

//Implementation of DOM manipulation to add adventure details to DOM
function addAdventureDetailsToDOM(adventure) {
  console.log(adventure);
  // TODO: MODULE_ADVENTURE_DETAILS
  // 1. Add the details of the adventure to the HTML DOM
  document.getElementById("adventure-name").append(adventure.name);
  document.getElementById("adventure-subtitle").append(adventure.subtitle);
    for(let i=0;i<adventure.images.length;i++)
   {
    var div=document.createElement("div");
    
     var img=document.createElement("img");
     img.setAttribute("class","activity-card-image");
     img.src=adventure.images[i];
     
     div.append(img);
     document.getElementById("photo-gallery").append(div);
   }
   document.getElementById("adventure-content").append(adventure.content);
 


}
function getCarouselOuterStructure() {
  return `
  <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel" style="width:70vw;height:50vh">
    <div class="carousel-inner h-100" id="carousel-item-parent">
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>`;
}

//Implementation of bootstrap gallery component
function addBootstrapPhotoGallery(images) {
  let element=getCarouselOuterStructure();
  let newEle=document.getElementById("photo-gallery");
  newEle.innerHTML=element;
  const finalEle=document.getElementById("carousel-item-parent");
    images.forEach((link, idx) => {
      const carouseItemElement = document.createElement("div");
  
      // Set as active if id is 0 i.e, first element
      idx === 0
        ? carouseItemElement.classList.add("carousel-item", "h-100", "active")
        : carouseItemElement.classList.add("carousel-item", "h-100");
  
      carouseItemElement.innerHTML = `<img src=${link} class="w-100 h-100" alt="..." style="object-fit:cover">`;
      const finalEle=document.getElementById("carousel-item-parent");
      finalEle.append(carouseItemElement);
  });
  // TODO: MODULE_ADVENTURE_DETAILS
  // 1. Add the bootstrap carousel to show the Adventure images

}

//Implementation of conditional rendering of DOM based on availability
function conditionalRenderingOfReservationPanel(adventure) {
  let sold_out = document.getElementById("reservation-panel-sold-out");
  let reservation = document.getElementById("reservation-panel-available");
  if (adventure.available) {
    reservation.style.display = "block";
    sold_out.style.display = "none";
    let reserve_cost = document.getElementById("reservation-person-cost");
    reserve_cost.innerHTML = adventure.costPerHead;
  } else {
    sold_out.style.display = "block";
    reservation.style.display = "none";
  }
  // TODO: MODULE_RESERVATIONS
  // 1. If the adventure is already reserved, display the sold-out message.

}

//Implementation of reservation cost calculation based on persons
function calculateReservationCostAndUpdateDOM(adventure, persons) {
  document.getElementById("reservation-cost").innerHTML=adventure.costPerHead*persons;
  // document.getElementById("reservation-person-cost").innerHTML=`${persons*adventure.costPerHead}`;

  // TODO: MODULE_RESERVATIONS
  // 1. Calculate the cost based on number of persons and update the reservation-cost field

}

//Implementation of reservation form submission
function captureFormSubmit(adventure) {
  // TODO: MODULE_RESERVATIONS
  console.log(adventure);
  let element=document.getElementById("myForm");
  element.addEventListener("submit", async function(event){
    event.preventDefault();
    let name=document.getElementsByClassName("form-control")[0].value;
    let date=document.getElementsByClassName("form-control")[1].value;
    let persons=document.getElementsByClassName("form-control")[2].value;
    let data={name:name,
    date:new Date(date),
    person:persons,
    adventure:adventure.id
  }
    try{
      const url=`${config.backendEndpoint}/reservations/new`;
    const res=await fetch(url,{
      method: 'POST',
      headers: {
      'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
      });
      console.log(res);
      alert("success");
    //  window.location.reload();
    }
    catch{
      alert("failed");
    }
    

  // fetch(config.backendEndpoint+"/reservations/new",options);
  console.log(data);
  });
  // 1. Capture the query details and make a POST API call using fetch() to make the reservation
  // 2. If the reservation is successful, show an alert with "Success!" and refresh the page. If the reservation fails, just show an alert with "Failed!".
}
// async function fetchCall(data,options){
//   let finalData=await fetch(config.backendEndpoint+"/frontend/pages/adventures/detail/?adventure="+options.adventure+"/reservations/new",options);
//   return finalData;
// }

//Implementation of success banner after reservation
function showBannerIfAlreadyReserved(adventure) {
  // TODO: MODULE_RESERVATIONS
  console.log(adventure);
  if(adventure.reserved){
  let reservedBanner=document.getElementById("reserved-banner").style.display="block";}
  else{
    let reservedBanner=document.getElementById("reserved-banner").style.display="none";
  }

  // 1. If user has already reserved this adventure, show the reserved-banner, else don't

}

export {
  getAdventureIdFromURL,
  fetchAdventureDetails,
  addAdventureDetailsToDOM,
  addBootstrapPhotoGallery,
  conditionalRenderingOfReservationPanel,
  captureFormSubmit,
  calculateReservationCostAndUpdateDOM,
  showBannerIfAlreadyReserved,
};
