import config from "../conf/index.js";
let ele=document.getElementById("data");
async function init() {
  //Fetches list of all cities along with their images and description
  let cities = await fetchCities();
  console.log(cities);

  // console.log('From init()');
  //Updates the DOM with the cities
  try{

  if (cities) {
    cities.forEach((key) => {
     addCityToDOM(key.id, key.city, key.description, key.image);
    // ele.innerHTML=ele.innerHTML+gotEle;
    });
    console.log(ele);
  }}
  catch (error) {
    console.error("Error initializing:", error);
  }
}

//Implementation of fetch call
async function fetchCities() {
  // TODO: MODULE_CITIES
  try{
  let citiesData=await fetch(config.backendEndpoint + "/cities");
  let fCityData=await citiesData.json();
  console.log(fCityData);
  return fCityData;}
  catch{
    return null;
  }
  // 1. Fetch cities using the Backend API and return the data

}

//Implementation of DOM manipulation to add cities
function addCityToDOM(id, city, description, image) {

  let tempContainer = document.createElement("div");
  tempContainer.innerHTML =
  `<div class="col-12 col-lg-3 col-sm-6 mt-5" >
    <a href="pages/adventures/?city=${id}" id="${id}">
    <div class="tile"><img src="${image}" alt="${id}" />
    <div class="tile-text">
    <h2>${city}</h2>
    <p>${description}</p>
    </div>
    </div>
    
   </a>
  </div>`;
 
 
  document.getElementById("data").append(tempContainer.firstChild);
  
  // return tempContainer.firstChild;
  
  // TODO: MODULE_CITIES

  // 1. Populate the City details and insert those details into the DOM

}
console.log(ele);
export { init, fetchCities, addCityToDOM };
