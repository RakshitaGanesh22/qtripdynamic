
const config = { backendEndpoint: "http://13.201.89.222:8082" };

export default config;
